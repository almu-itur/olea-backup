<div class="aps-promobar">
        <div>
            <a href="http://codecanyon.net/item/accesspress-social-icons-pro/9700839?ref=AccessKeys" target="_blank" class="ap-upgrade-first"><img src="<?php echo APS_IMAGE_DIR.'/accesspress-social-icons-pro-upgrade.jpg';?>"></a>
        </div>
        <div class="aps-demo-links">
            <div class="aps-btn-group">
                <a href="http://demo.accesspressthemes.com/wordpress-plugins/accesspress-social-icons-pro/" target="_blank" class="aps-btn aps-btn-default aps-btn-demo">DEMO</a>
                <a href="http://codecanyon.net/item/accesspress-social-icons-pro/9700839?ref=AccessKeys" target="_blank" class="aps-btn aps-btn-default aps-btn-upgrade">UPGRADE</a>
            </div>
        </div>
        <div>
            <a href="http://demo.accesspressthemes.com/wordpress-plugins/accesspress-social-icons-pro/" target="_blank" class="ap-upgrade-first"><img src="<?php echo APS_IMAGE_DIR.'/accesspress-social-icons-pro.jpg';?>"></a>
        </div>
        <div class="aps-demo-links">
            <div class="aps-btn-group">
                <a href="http://demo.accesspressthemes.com/wordpress-plugins/accesspress-social-icons-pro/" target="_blank" class="aps-btn aps-btn-default aps-btn-demo">DEMO</a>
                <a href="http://codecanyon.net/item/accesspress-social-icons-pro/9700839?ref=AccessKeys" target="_blank" class="aps-btn aps-btn-default aps-btn-upgrade">UPGRADE</a>
            </div>
        </div>
        <div class="aps-enquiry-block">
          <p>If you have any questions regarding pro version, please contact us from <a href="https://accesspressthemes.com/contact/" target="_blank">here</a></p>
      </div>
  </div>