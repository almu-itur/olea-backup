License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
AccessPress Parallax Pro WordPress Theme, Copyright 2015 AccessPress Themes
AccessPress Parallax Pro is distributed under the terms of the GNU GPL v3


Install Steps:
--------------

1. Activate the theme
2. Go to the Theme Option page
3. Setup theme options


Updates
-------
Version 4.0.1
 - Fixed bugs of video CTA at ipad and mobile devices
 - Fixed bugs of shopping cart function
 - Fixed bugs at slider function
 
Version 4.0
 - Added new layout for several sections
 	-- Blog section
 	-- Portfolio Section with new features
 	-- Testimonials Section with new features
 	-- Pricing Table
 	-- Team Sections
 - Added floating menu at side
 - Added new widget for Video background
 - Changed the woocommerce layout

Version 3.1.1
- Fixed: Problem in showing the team content for multiple team section
- Added: Year added along with month and day in the post published date
- Fixed: Auto Collapse of Left menu on click for non parallax menu
- Fixed: Google Map API key added

Version 3.1
- Full compatible with WooCommerce

Version 3
- Fontawesome Updated from 4.2 to 4.5
- Blog Section View All button Bug fixed
- Service Section left side header magin bottom problem fixed
- Facebook Widget Updated to be compatible with the latest Facebook API 2.5